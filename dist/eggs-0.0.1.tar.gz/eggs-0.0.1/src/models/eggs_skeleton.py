import torch
from torch import nn






class eggs_1(nn.Modules):
    pass